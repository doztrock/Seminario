SET SERVEROUTPUT ON;

BEGIN
    getprojects();
END;