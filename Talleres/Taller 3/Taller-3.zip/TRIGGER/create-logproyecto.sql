/* creaci�n de un archivo log para los Proyectos*/
CREATE TABLE logproyecto (
    fecha     VARCHAR2(50),
    accion    CHAR(1),
    usuario   VARCHAR2(50)
);